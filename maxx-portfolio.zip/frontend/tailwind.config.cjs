module.exports = {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          900: "#071013",
          800: "#0b1820",
          600: "#0f2a3a",
          accent: "#58a6ff"
        }
      }
    }
  },
  plugins: []
};