import React from "react";
import Header from "./components/Header";
import About from "./components/About";
import Skills from "./components/Skills";
import Projects from "./components/Projects";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <section className="pt-10">
          <About />
        </section>
        <section className="pt-8">
          <Skills />
        </section>
        <section className="pt-8">
          <Projects />
        </section>
        <section className="pt-8 pb-16">
          <Contact />
        </section>
      </main>
      <Footer />
    </div>
  );
}