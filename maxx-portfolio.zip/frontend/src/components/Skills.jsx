import React from "react";

const skills = [
  "Python", "Java", "C", "Ethical Hacking", "Cybersecurity",
  "AI / ML", "React", "FastAPI", "PostgreSQL", "Git"
];

const Skills = () => {
  return (
    <div id="skills" className="max-w-4xl mx-auto px-6 mt-6">
      <div className="bg-brand-800 rounded-xl p-8 shadow">
        <h2 className="text-2xl font-bold text-white">Skills</h2>
        <div className="mt-4 flex flex-wrap">
          {skills.map((s) => (
            <span key={s} className="mr-3 mt-3 inline-block bg-slate-700 px-3 py-1 rounded-full text-sm text-slate-100">{s}</span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Skills;