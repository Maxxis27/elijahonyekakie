import React from "react";

const Footer = () => (
  <footer className="bg-brand-800 mt-8 py-6">
    <div className="max-w-4xl mx-auto px-6 text-center text-slate-400">
      <p>© {new Date().getFullYear()} Elijah Chidibere Onyekakie — <a className="text-brand-accent" href="https://www.linkedin.com/in/elijah-onyekakie-2a4160375">LinkedIn</a></p>
    </div>
  </footer>
);

export default Footer;