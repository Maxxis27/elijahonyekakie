import React, { useState } from "react";
import axios from "axios";

const Contact = () => {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [status, setStatus] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    setStatus("sending");
    try {
      await axios.post("/api/contact", form);
      setStatus("sent");
      setForm({ name: "", email: "", message: "" });
    } catch (err) {
      setStatus("error");
    }
  };

  return (
    <div id="contact" className="max-w-4xl mx-auto px-6 mt-6">
      <div className="bg-brand-800 rounded-xl p-8 shadow">
        <h2 className="text-2xl font-bold text-white">Contact</h2>
        <p className="mt-2 text-slate-300">Reach me at <a className="text-brand-accent" href="mailto:elijahonyeka1716@gmail.com">elijahonyeka1716@gmail.com</a> or use the form below.</p>

        <form onSubmit={submit} className="mt-4 grid grid-cols-1 gap-3">
          <input required placeholder="Your name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}
                 className="p-3 rounded bg-slate-900 text-white" />
          <input required placeholder="Your email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}
                 className="p-3 rounded bg-slate-900 text-white" />
          <textarea required placeholder="Message" value={form.message} onChange={e=>setForm({...form,message:e.target.value})}
                    className="p-3 rounded bg-slate-900 text-white h-28" />
          <div className="flex items-center space-x-3">
            <button type="submit" className="px-4 py-2 rounded bg-brand-accent text-black font-medium">
              {status === "sending" ? "Sending..." : "Send message"}
            </button>
            {status === "sent" && <span className="text-green-400">Message sent — thank you!</span>}
            {status === "error" && <span className="text-red-400">Error sending message.</span>}
          </div>
        </form>
      </div>
    </div>
  );
};

export default Contact;