import React, { useEffect, useState } from "react";
import axios from "axios";

const Projects = () => {
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    axios.get("/api/projects").then(res => setProjects(res.data)).catch(() => {
      setProjects([
        { id: 1, title: "Maxx SaaS", desc: "Exploring SaaS workflows & automation tools" },
        { id: 2, title: "Password Manager App", desc: "Full-stack security-focused project" },
        { id: 3, title: "Journal Web App", desc: "Digital journaling solution with modern UI" }
      ]);
    });
  }, []);

  return (
    <div id="projects" className="max-w-4xl mx-auto px-6 mt-6">
      <div className="bg-brand-800 rounded-xl p-8 shadow">
        <h2 className="text-2xl font-bold text-white">Projects</h2>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          {projects.map(p => (
            <article key={p.id} className="p-4 bg-slate-900 rounded-lg">
              <h3 className="text-lg font-semibold text-white">{p.title}</h3>
              <p className="mt-2 text-slate-300">{p.desc}</p>
              <div className="mt-3">
                <a className="text-sm text-brand-accent hover:underline" href={p.link || "#"} target="_blank" rel="noreferrer">View project</a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Projects;