import React from "react";

const Header = () => {
  return (
    <header className="bg-brand-800 py-6 shadow-sm">
      <div className="max-w-4xl mx-auto px-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-white">Elijah Onyekakie</h1>
          <p className="text-sm text-slate-300">Building smart digital solutions with code, creativity, and AI.</p>
        </div>
        <nav className="space-x-4">
          <a href="#about" className="text-sm text-slate-200 hover:text-brand-accent">About</a>
          <a href="#skills" className="text-sm text-slate-200 hover:text-brand-accent">Skills</a>
          <a href="#projects" className="text-sm text-slate-200 hover:text-brand-accent">Projects</a>
          <a href="#contact" className="text-sm text-slate-200 hover:text-brand-accent">Contact</a>
        </nav>
      </div>
    </header>
  );
};

export default Header;