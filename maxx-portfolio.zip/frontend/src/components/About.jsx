import React from "react";

const About = () => {
  return (
    <div id="about" className="max-w-4xl mx-auto px-6">
      <div className="bg-brand-800 rounded-xl p-8 shadow">
        <h2 className="text-2xl font-bold text-white">About Me</h2>
        <p className="mt-4 text-slate-300 leading-relaxed">
          I’m <strong>Elijah Chidibere Onyekakie</strong>, a software programmer and aspiring ethical hacker from Kano, Nigeria.
          I build solutions that combine <em>security, intelligence, and creativity</em>. I work with Python, Java, C,
          and I am exploring AI/ML and cybersecurity. Currently working on SaaS workflows and secure web applications.
        </p>
      </div>
    </div>
  );
};

export default About;