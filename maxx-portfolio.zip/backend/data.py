PROJECTS = [
    {"id": 1, "title": "Maxx SaaS", "desc": "Exploring SaaS workflows & automation tools", "link": ""},
    {"id": 2, "title": "Password Manager App", "desc": "Full-stack security-focused project", "link": ""},
    {"id": 3, "title": "Journal Web App", "desc": "Digital journaling solution with modern UI", "link": ""}
]