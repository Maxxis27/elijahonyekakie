from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr
from typing import List
import uvicorn
from data import PROJECTS

app = FastAPI(title="Maxx Portfolio API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Project(BaseModel):
    id: int
    title: str
    desc: str
    link: str = ""

class ContactIn(BaseModel):
    name: str
    email: EmailStr
    message: str

@app.get("/api/projects", response_model=List[Project])
def get_projects():
    return PROJECTS

@app.post("/api/contact")
async def post_contact(payload: ContactIn):
    print("Contact message received:", payload.dict())
    return {"status": "ok", "message": "Message received"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)